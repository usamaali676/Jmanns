<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <meta name="description" content="Multipages HTML5 Template">
    <meta name="author" content="">

    <!-- Page Title -->
    <title>Jmanns Locksmith</title>

    <!-- Favicon and touch Icons -->
    <link href="assets/images/favicon.png" rel="shortcut icon" type="image/png">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Lead Style -->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>
<?php /**PATH A:\laragon\www\Jmanns\resources\views/layout/partials/head.blade.php ENDPATH**/ ?>