<?php $__env->startComponent('mail::message'); ?>

<b>Name:</b><?php echo e($details['name']); ?><br>
<b>Email:</b><?php echo e($details['email']); ?><br>
<b>Phone:</b><?php echo e($details['phone']); ?><br>
<b>Subject:</b><?php echo e($details['subject']); ?><br>
<b>Message:</b><?php echo e($details['message']); ?><br>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH A:\laragon\www\Jmanns\resources\views/email/contact.blade.php ENDPATH**/ ?>