<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH A:\laragon\www\Jmanns\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>