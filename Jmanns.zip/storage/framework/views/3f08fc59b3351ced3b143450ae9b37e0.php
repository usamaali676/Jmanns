<?php $__env->startSection('content'); ?>

<style>
    .page_header .page_header_content {
    position: relative;
    background-image: url('<?php echo e(asset('assets/images/services/anner2.webp')); ?>');;
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
    margin: 0px;
    padding: 135px 0px 135px 0px;
    text-align: center;
}
</style>
<div class="page_header">
    <div class="page_header_content">
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="active">Services</li>
            </ul>
            <h2 style="color: white" class="heading">Locksmith Services</h2>
        </div>
    </div>
</div>

<div class="main_wrapper">
    <div class="section services">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="iconbox">
                        <div class="iconbox_wrapper">
                            <div class="iconbox_image">
                                <img src="<?php echo e(asset('assets/images/services/1.webp')); ?>" alt="img">
                                <div class="iconbox_icon">
                                    <a href="tel:9285811957"><img src="<?php echo e(asset('assets/images/services/Emergency-Mobile-Locksmith-Services.svg')); ?>"
                                            alt="icon"></a>
                                </div>
                            </div>
                            <div class="iconbox_content">
                                <h3><a href="tel:9285811957">Emergency & Mobile Locksmith Services</a></h3>
                                <p>Fast, 24/7 locksmith assistance at your location—perfect for homes, businesses, or
                                    vehicles.</p>
                                <div class="read_more">
                                    <a href="tel:9285811957"><span>Get Service</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="iconbox">
                        <div class="iconbox_wrapper">
                            <div class="iconbox_image">
                                <img src="<?php echo e(asset('assets/images/services/3.webp')); ?>" alt="img">
                                <div class="iconbox_icon">
                                    <a href="tel:9285811957"><img src="<?php echo e(asset('assets/images/services/Lock-Installation-Replacement.svg')); ?>" alt="icon"></a>
                                </div>
                            </div>
                            <div class="iconbox_content">
                                <h3><a href="tel:9285811957">Lock Installation & Replacement</a></h3>
                                <p>Secure your property with expert lock installation or replacement for any door or
                                    entry.</p>
                                <div class="read_more">
                                    <a href="tel:9285811957"><span>Get Service</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="iconbox">
                        <div class="iconbox_wrapper">
                            <div class="iconbox_image">
                                <img src="<?php echo e(asset('assets/images/services/4.webp')); ?>" alt="img">
                                <div class="iconbox_icon">
                                    <a href="tel:9285811957"><img src="<?php echo e(asset('assets/images/services/Lock-Rekeying-Key-Services.svg')); ?>"
                                            alt="icon"></a>
                                </div>
                            </div>
                            <div class="iconbox_content">
                                <h3><a href="tel:9285811957">Lock Rekeying & Key Services</a></h3>
                                <p>Lost keys or need better control? We offer quick rekeying, key duplication, and
                                    master key.</p>
                                <div class="read_more">
                                    <a href="tel:9285811957"><span>Get Service</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="iconbox">
                        <div class="iconbox_wrapper">
                            <div class="iconbox_image">
                                <img src="<?php echo e(asset('assets/images/services/6.webp')); ?>" alt="img">
                                <div class="iconbox_icon">
                                    <a href="tel:9285811957"><img src="<?php echo e(asset('assets/images/services/Residential-Commercial-Lock-Repair.svg')); ?>"
                                            alt="icon"></a>
                                </div>
                            </div>
                            <div class="iconbox_content">
                                <h3><a href="tel:9285811957">Residential & Commercial Lock Repair</a></h3>
                                <p>From home doors to office entry systems, we provide dependable lock repairs for all
                                    settings.</p>
                                <div class="read_more">
                                    <a href="tel:9285811957"><span>Get Service</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="iconbox">
                        <div class="iconbox_wrapper">
                            <div class="iconbox_image">
                                <img src="<?php echo e(asset('assets/images/services/2.webp')); ?>" alt="img">
                                <div class="iconbox_icon">
                                    <a href="tel:9285811957"><img src="<?php echo e(asset('assets/images/services/Lockout-Services.svg')); ?>"
                                            alt="icon"></a>
                                </div>
                            </div>
                            <div class="iconbox_content">
                                <h3><a href="tel:9285811957">Lockout Services</a></h3>
                                <p>Locked out of your house, office, or car? We’ll get you back inside quickly, safely,
                                    and without any stress.</p>
                                <div class="read_more">
                                    <a href="tel:9285811957"><span>Get Service</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="iconbox">
                        <div class="iconbox_wrapper">
                            <div class="iconbox_image">
                                <img src="<?php echo e(asset('assets/images/services/5.webp')); ?>" alt="img">
                                <div class="iconbox_icon">
                                    <a href="tel:9285811957"><img src="<?php echo e(asset('assets/images/services/Lock-Repair-Services.svg')); ?>"
                                            alt="icon"></a>
                                </div>
                            </div>
                            <div class="iconbox_content">
                                <h3><a href="tel:9285811957">Lock Repair Services</a></h3>
                                <p>Locked out of your house, office, or car? We’ll get you back inside quickly, safely,
                                    and without any hassle or delay.
                                </p>
                                <div class="read_more">
                                    <a href="tel:9285811957"><span>Get Service</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH A:\laragon\www\Jmanns\resources\views/services.blade.php ENDPATH**/ ?>