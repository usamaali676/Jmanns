<?php $__env->startComponent('mail::message'); ?>

<b>Name:</b><?php echo new \Illuminate\Support\EncodedHtmlString($details['name']); ?><br>
<b>Email:</b><?php echo new \Illuminate\Support\EncodedHtmlString($details['email']); ?><br>
<b>Phone:</b><?php echo new \Illuminate\Support\EncodedHtmlString($details['phone']); ?><br>
<b>Subject:</b><?php echo new \Illuminate\Support\EncodedHtmlString($details['subject']); ?><br>
<b>Message:</b><?php echo new \Illuminate\Support\EncodedHtmlString($details['message']); ?><br>

<?php echo $__env->renderComponent(); ?>

<?php /**PATH A:\laragon\www\Jmanns\resources\views/emails/contact.blade.php ENDPATH**/ ?>