    <!-- All JavaScript Files -->
    <script src="<?php echo e(asset('assets/js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/menu/ma5-menu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/aos/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/slick/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script><?php /**PATH A:\laragon\www\Jmanns\resources\views/layout/partials/scripts.blade.php ENDPATH**/ ?>